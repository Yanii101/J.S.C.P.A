package FXML;

import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Login {

    @FXML
    private TextField username;

    @FXML
    private ChoiceBox<?> usertype;

    @FXML
    private PasswordField password;

    @FXML
    void login(ActionEvent event) {

    }

}