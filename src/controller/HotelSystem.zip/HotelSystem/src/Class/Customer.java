package Class;

import Controller.Alerts;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Customer extends User{
    private int phonenum;
    private String email,cfname,clname;
    private LocalDate dob;
    private int offset = (50 + (25 * 2) + (25 * 2) + (3 * 4) + (3 + 4) + (25 * 2) + (25 * 2) + (25 * 2) + (1 * 4));
    Alerts a=new Alerts();
    public Customer() {
        this(null,0,"","","",0,"");
    }

    public Customer(LocalDate dob,int phonenum, String email, String cfname, String clname,int userid,String password) {
        super(userid, password);
        this.phonenum = phonenum;
        this.email = email;
        this.cfname = cfname;
        this.clname = clname;
        this.dob=dob;

    }

    public Customer(User u, Customer c) {
        super(u);
        this.phonenum = c.phonenum;
        this.email = c.email;
        this.cfname = c.cfname;
        this.clname = c.clname;
        this.dob=c.dob;
    }

    public int getPhonenum() {
        return phonenum;
    }

    public void setPhonenum(int phonenum) {
        this.phonenum = phonenum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCfname() {
        return cfname;
    }

    public void setCfname(String cfname) {
        this.cfname = cfname;
    }

    public String getClname() {
        return clname;
    }

    public void setClname(String clname) {
        this.clname = clname;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public void display()
    {
        System.out.println("Customer{" +
                "phonenum=" + phonenum +
                ", email='" + email + '\'' +
                ", cfname='" + cfname + '\'' +
                ", clname='" + clname + '\'' +
                ", dob=" + dob +
                ", id=" + id +
                ", password='" + password + '\'' +
                '}');
    }

    public String searchfunction(int id)
    {
        return getEmail();
    }
    public int searchfunction(int id,String name)
    {
        return getPhonenum();
    }

    public void addCustomer(Customer c)
    {
        try {
            updateIdx(getId());
        } catch (IOException e) {
            e.printStackTrace();
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd LLLL yyyy");
        String sdob = c.getDob().format(formatter);
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile("customer.dat", "rw");
            raf.seek((super.getId() - 1) * offset);
            raf.writeInt(super.getId());
            raf.writeUTF(c.getPassword());
            raf.writeUTF(sdob);
            raf.writeInt(c.getPhonenum());
            raf.writeUTF(c.getEmail());
            raf.writeUTF(c.getCfname());
            raf.writeUTF(c.getClname());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean removecust(int num)
    {
        Customer c=new Customer();
        RandomAccessFile raf=null;
        try{
            raf = new RandomAccessFile("customer.dat", "rw");
            raf.seek((num - 1) * offset);
            raf.writeInt(super.getId());
            raf.writeUTF(c.getPassword());
            raf.writeUTF(c.getDob().toString());
            raf.writeInt(c.getPhonenum());
            raf.writeUTF(c.getEmail());
            raf.writeUTF(c.getCfname());
            raf.writeUTF(c.getClname());
            a.success();
        } catch (FileNotFoundException e) {
            a.notfound();
        }catch (IOException e)
        {
            System.out.println("not in file");
        }
        finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }
}
