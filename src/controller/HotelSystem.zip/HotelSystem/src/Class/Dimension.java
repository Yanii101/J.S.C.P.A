package Class;

public class Dimension {
    private int width,length;

    public Dimension() {
        this(0,0);
    }

    public Dimension(int width, int length) {
        this.width = width;
        this.length = length;
    }
    public Dimension(String width, String length) {
        this.width=Integer.parseInt(width);
        this.length = Integer.parseInt(length);
    }
    public Dimension(Dimension d) {
        this.width = d.width;
        this.length = d.length;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }
}
