package Class;

import Controller.Alerts;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Reservation {
    private int resid = 0;
    private LocalDate resdate;
    private Room room;
    Alerts a=new Alerts();
    private int offset = (50 + (25 * 2) + (25 * 2) + (3 * 4) + (3 + 4) + (25 * 2) + (25 * 2) + (25 * 2) + (1 * 4));


    public Reservation() {
        this(0, null, null);
    }

    public Reservation(int resid, LocalDate resdate, int roomnum, int beds, String type, float cost, Dimension d) {
        this.resid = resid;
        this.resdate = resdate;
        this.room = new Room(roomnum, beds, type, cost, d);
    }

    public Reservation(int resid, LocalDate resdate, Room room) {
        this.resid = resid;
        this.resdate = resdate;
        this.room = room;
    }

    public Reservation(Reservation r) {
        this.resid = r.resid;
        this.resdate = r.resdate;
        this.room = r.room;
    }

    public void setResid(int resid) {
        this.resid = resid;
    }

    public LocalDate getResdate() {
        return resdate;
    }

    public void setResdate(LocalDate resdate) {
        this.resdate = resdate;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }


    public int getResid() throws IOException {
        File file = new File("res.txt");
        initIdxFile();
        try {
            Scanner in = new Scanner(new FileReader(file));
            if (in.hasNextInt()) {
                resid = in.nextInt();
            }
            return resid;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return 1;
    }


    public void updateResid(int idx) {
        BufferedWriter writer = null;
        File file = new File("res.txt");

        try {
            writer = new BufferedWriter(new FileWriter(file));

            writer.write(resid + 1 + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void initIdxFile() {
        Writer writer = null;
        File file = new File("res.txt");

        if (!file.exists()) {
            try {
                writer = new BufferedWriter(new OutputStreamWriter(
                        new FileOutputStream("res.txt"), "utf-8"));
                writer.write(1 + "\n");
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public void bookroom(Reservation r) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd LLLL yyyy");


        try {
            r.updateResid(r.getResid());
            r.getRoom().updateRoomnum(r.getRoom().getRoomnum());
        } catch (IOException e)
        {
            e.printStackTrace();
        }

        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile("reservation.dat", "rw");
            raf.seek((r.getResid() - 1) * offset);
            raf.writeInt(r.getResid());
            raf.writeUTF(String.valueOf(r.getResdate()));
            raf.writeInt(r.getRoom().getRoomnum());
            raf.writeInt(r.getRoom().getNumbeds());
            raf.writeUTF(r.getRoom().getRoomtype());
            raf.writeFloat(r.getRoom().getRoomcost());
            raf.writeInt(r.getRoom().getDimension().getWidth());
            raf.writeInt(r.getRoom().getDimension().getLength());
            System.out.println("writing");
            a.success();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
