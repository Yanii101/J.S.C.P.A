package Class;

import Controller.Alerts;
import javafx.scene.control.ChoiceBox;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Room {
    private int roomnum=0,numbeds;
    private String roomtype;
    private float roomcost;
    private Dimension dimension;
    private int offset = (50 + (25 * 2) + (25 * 2) + (3 * 4) + (3 + 4) + (25 * 2) + (25 * 2) + (25 * 2) + (1 * 4));
    Alerts a=new Alerts();

    public Room()
    {
        this(0,0,"",0,null);
    }
    public Room(int roomnum, int numbeds, String roomtype, float roomcost, int width,int height)
    {
        this.roomnum = roomnum;
        this.numbeds = numbeds;
        this.roomtype = roomtype;
        this.roomcost = roomcost;
        this.dimension = new Dimension(width,height);
    }
    public Room(int roomnum, int numbeds, String roomtype, float roomcost, Dimension dimension)
    {
        this.roomnum = roomnum;
        this.numbeds = numbeds;
        this.roomtype = roomtype;
        this.roomcost = roomcost;
        this.dimension = dimension;
    }
    public Room(Room room)
    {
        this.roomnum = room.roomnum;
        this.numbeds = room.numbeds;
        this.roomtype = room.roomtype;
        this.roomcost = room.roomcost;
        this.dimension = room.dimension;
    }

    public void setRoomnum(int roomnum) {
        this.roomnum = roomnum;
    }

    public int getNumbeds() {
        return numbeds;
    }

    public void setNumbeds(int numbeds) {
        this.numbeds = numbeds;
    }

    public String getRoomtype() {
        return roomtype;
    }

    public void setRoomtype(String roomtype) {
        this.roomtype = roomtype;
    }

    public float getRoomcost() {
        return roomcost;
    }

    public void setRoomcost(float roomcost) {
        this.roomcost = roomcost;
    }

    public Dimension getDimension() {
        return dimension;
    }

    public void setDimension(Dimension dimension) {
        this.dimension = dimension;
    }

    public int getRoomnum() throws IOException {
        File file = new File("room.txt");
        initIdxFile();

        try {
            Scanner in = new Scanner(new FileReader(file));
            if (in.hasNextInt()) {
                roomnum = in.nextInt();
            }

            return roomnum;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return 1;
    }


    public void updateRoomnum(int idx) {
        BufferedWriter writer = null;
        File file = new File("room.txt");

        try {
            writer = new BufferedWriter(new FileWriter(file));

            writer.write(idx + 1 + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void initIdxFile() {
        Writer writer = null;
        File file = new File("res.txt");

        if (!file.exists()) {
            try {
                writer = new BufferedWriter(new OutputStreamWriter(
                        new FileOutputStream("res.txt"), "utf-8"));
                writer.write(1 + "\n");
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public void addroom(Room r)
    {
        try {
            r.updateRoomnum(r.getRoomnum());
        } catch (IOException e)
        {
            e.printStackTrace();
        }

        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile("room.dat", "rw");
            raf.seek((r.getRoomnum() - 1) * offset);
            raf.writeInt(r.getRoomnum());
            raf.writeInt(r.getNumbeds());
            raf.writeUTF(r.getRoomtype());
            raf.writeFloat(r.getRoomcost());
            raf.writeInt(r.getDimension().getWidth());
            raf.writeInt(r.getDimension().getLength());
            a.success();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public void updateroom(int num,Room r)
    {
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile("room.dat", "rw");
            raf.seek((num - 1) * offset);
            raf.writeInt(num);
            raf.writeInt(r.getNumbeds());
            raf.writeUTF(r.getRoomtype());
            raf.writeFloat(r.getRoomcost());
            raf.writeInt(r.getDimension().getWidth());
            raf.writeInt(r.getDimension().getLength());
            a.success();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}

