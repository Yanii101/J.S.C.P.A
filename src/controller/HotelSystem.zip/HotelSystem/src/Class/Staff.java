package Class;

import Controller.Alerts;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

public class Staff extends User{
    private LocalDate dob,employdate;
    private String sfname,slanme;
    private int offset = (50 + (25 * 2) + (25 * 2) + (3 * 4) + (3 + 4) + (25 * 2) + (25 * 2) + (25 * 2) + (1 * 4));
    Alerts a=new Alerts();

    public Staff() {
        this(0,"",null,null,"","");
    }

    public Staff(int id, String password, LocalDate dob, LocalDate employdate, String sfname, String slanme) {
        super(id, password);
        this.dob = dob;
        this.employdate = employdate;
        this.sfname = sfname;
        this.slanme = slanme;
    }

    public Staff(Staff s) throws IOException {
        this(s.getId(),s.getPassword(),s.getDob(),s.getEmploydate(),s.getSfname(),s.getSfname());
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public LocalDate getEmploydate() {
        return employdate;
    }

    public void setEmploydate(LocalDate employdate) {
        this.employdate = employdate;
    }

    public String getSfname() {
        return sfname;
    }

    public void setSfname(String sfname) {
        this.sfname = sfname;
    }

    public String getSlanme() {
        return slanme;
    }

    public void setSlanme(String slanme) {
        this.slanme = slanme;
    }

    public void display()
    {
        System.out.println("Staff{" +
                "dob=" + dob +
                ", employdate=" + employdate +
                ", sfname='" + sfname + '\'' +
                ", slanme='" + slanme + '\'' +
                ", id=" + id +
                ", password='" + password + '\'' +
                '}');
    }



    public void addStaff(Staff s)
    {

        try {
            updateIdx(getId());
        } catch (IOException e) {
            e.printStackTrace();
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd LLLL yyyy");
        String sdob = s.getDob().format(formatter);
        String edate = s.getEmploydate().format(formatter);
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile("staff.dat", "rw");
            raf.seek((super.getId() - 1) * offset);
            raf.writeInt(super.getId()-1);
            raf.writeUTF(s.getPassword());
            raf.writeUTF(sdob);
            raf.writeUTF(edate);
            raf.writeUTF(s.getSfname());
            raf.writeUTF(s.getSlanme());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean removestaff(int num)
    {
        Staff s=new Staff();
        RandomAccessFile raf=null;
        try{
            raf = new RandomAccessFile("staff.dat", "rw");
            raf.seek((num - 1) * offset);
            raf.writeInt(super.getId());
            raf.writeUTF(s.getPassword());
            raf.writeUTF(s.getDob().toString());
            raf.writeUTF(s.getEmploydate().toString());
            raf.writeUTF(s.getSfname());
            raf.writeUTF(s.getSlanme());
            a.success();
        } catch (FileNotFoundException e) {
            a.notfound();
        }catch (IOException e)
        {
            System.out.println("not in file");
        }
        finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }
}