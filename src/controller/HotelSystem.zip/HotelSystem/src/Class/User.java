package Class;

import java.io.*;
import java.util.Scanner;

public abstract class User
{
    protected int id=0;
    protected String password;

    public User() {
        this(0,"");
    }

    public User(int id, String password) {
        this.id = id=0;
        this.password = password;
    }

    public User(User u) {
        this.id = u.id;
        this.password = u.password;
    }


    public void setId(int id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() throws IOException {
        File file = new File("idx.txt");
        initIdxFile();

        try {
            Scanner in = new Scanner(new FileReader(file));
            if (in.hasNextInt()) {
                id = in.nextInt();
            }

            return id;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return 1;
    }


    public void updateIdx(int idx) {
        BufferedWriter writer = null;
        File file = new File("idx.txt");

        try {
            writer = new BufferedWriter(new FileWriter(file));

            writer.write(idx + 1 + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void initIdxFile() {
        BufferedWriter writer = null;
        File file = new File("idx.txt");

        if (!file.exists()) {
            try {
                writer = new BufferedWriter(new FileWriter(file));

                writer.write(1 + "\n");
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", password='" + password + '\'' +
                '}';
    }
}
