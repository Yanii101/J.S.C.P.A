package Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

import Class.*;
import javafx.stage.Stage;


public class AddRoom implements Initializable {
    Room r;
    Dimension d;
    Alerts a = new Alerts();
    private int offset = (50 + (25 * 2) + (25 * 2) + (3 * 4) + (3 + 4) + (25 * 2) + (25 * 2) + (25 * 2) + (1 * 4));

    @FXML
    private ChoiceBox<String> rtype;

    @FXML
    private TextField length;

    @FXML
    private TextField bednum;

    @FXML
    private TextField width;

    @FXML
    private TextField roomnum;

    ObservableList<String> roomtype = FXCollections.
            observableArrayList("Single", "Couple", "Family");

    @FXML
    void addroom(ActionEvent event) {
        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("res.txt"));
            int rnumber = scanner.nextInt();
            String rrtype = rtype.getValue();
            int wth = Integer.parseInt(width.getText());
            int lth = Integer.parseInt(length.getText());
            int bedn = Integer.parseInt(bednum.getText());
            float rcost = 0;
            if (rrtype.equals("Single")) {
                rcost = 200;
            }
            if (rrtype.equals("Couple")) {
                rcost = 400;
            }
            if (rrtype.equals("Family")) {
                rcost = 850;
            }
            d = new Dimension(wth, lth);
            r = new Room(rnumber, bedn, rrtype, rcost, d);
            r.addroom(r);


            Parent rootparent = null;
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/StaffMenu.fxml"));
            Scene rootscene = new Scene(rootparent);
            Stage appstage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            appstage.setResizable(false);
            appstage.setScene(rootscene);
            appstage.show();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {

        }

    }

    @FXML
    void editroom(ActionEvent event) {
        Scanner scanner = null;
        try {
            int rid = Integer.parseInt(roomnum.getText());

            String rrtype = rtype.getValue();
            int wth = Integer.parseInt(width.getText());
            int lth = Integer.parseInt(length.getText());
            int bedn = Integer.parseInt(bednum.getText());
            float rcost = 0;
            if (rrtype.equals("Single")) {
                rcost = 200;
            }
            if (rrtype.equals("Couple")) {
                rcost = 400;
            }
            if (rrtype.equals("Family")) {
                rcost = 850;
            }
            d = new Dimension(wth, lth);
            r = new Room(rid, bedn, rrtype, rcost, d);
            r.updateroom(rid,r);

            Parent rootparent = null;
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/StaffMenu.fxml"));
            Scene rootscene = new Scene(rootparent);
            Stage appstage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            appstage.setResizable(false);
            appstage.setScene(rootscene);
            appstage.show();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {

        }
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        rtype.setValue("Single");
        rtype.setItems(roomtype);

        Scanner scanner = null;
        RandomAccessFile r = null;
        try {
            scanner = new Scanner(new File("room.txt"));
            int intnum = scanner.nextInt();
            String result = Integer.toString(intnum+1);
            roomnum.setText(result);
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
