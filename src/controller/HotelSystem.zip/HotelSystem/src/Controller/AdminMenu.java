package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import Class.*;

import java.io.IOException;
import java.util.NoSuchElementException;


public class AdminMenu {
     Alerts a=new Alerts();
     Staff s=new Staff();
     Customer c=new Customer();

    @FXML
    void add(ActionEvent event) {
        Parent rootparent = null;
        try {
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/Staffsignup.fxml"));
                Scene rootscene = new Scene(rootparent);
                Stage appstage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                appstage.setResizable(false);
                appstage.setScene(rootscene);
                appstage.show();
            } catch(IOException e){
                e.printStackTrace();
            }
        }
    @FXML
    void addcust(ActionEvent event) {
        Parent rootparent = null;
        try {

            rootparent = FXMLLoader.load(getClass().getResource("../FXML/Customersignup.fxml"));
            Scene rootscene = new Scene(rootparent);
            Stage appstage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            appstage.setResizable(false);
            appstage.setScene(rootscene);
            appstage.show();
        } catch(IOException e){
            e.printStackTrace();
        }
    }
    @FXML
    void logout(ActionEvent event) {
        Parent rootparent = null;
        try {
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/login.fxml"));
            Scene rootscene=new Scene(rootparent);
            Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
            appstage.setScene(rootscene);
            appstage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void modres(ActionEvent event) {

    }

    @FXML
    void modroom(ActionEvent event) {

    }

    @FXML
    void remove(ActionEvent event) {
        try {
            String remove=a.search();
            int result = Integer.parseInt(remove);
            System.out.println(result);
            s.removestaff(result);
           // a.success();
        }catch (NullPointerException e)
        {
              a.invalidinput();
        }catch (NumberFormatException | NoSuchElementException ex)
        {
            a.invalidinput();
        }
    }
    @FXML
    void removecust(ActionEvent event) {
        try {
            String remove=a.search();
            int result = Integer.parseInt(remove);
            c.removecust(result);
        }catch (NullPointerException e)
        {
            a.invalidinput();
        }catch (NoSuchElementException | NumberFormatException ex)
        {
            a.invalidinput();
        }
    }
}
