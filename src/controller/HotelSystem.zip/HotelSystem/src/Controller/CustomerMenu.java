package Controller;


import IDCLASS.Roomid;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.fxml.FXML;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import Class.*;

import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;


public class CustomerMenu implements Initializable {
    private int offset = (50 + (25 * 2) + (25 * 2) + (3 * 4) + (3 + 4) + (25 * 2) + (25 * 2) + (25 * 2) + (1 * 4));
Alerts a=new Alerts();
User cust=new Customer();/**polymorphism here**/
    @FXML
    private TableView<Reservation> booktable;

    @FXML
    private TableView<Roomid> bookidtable;

    @FXML
    private TableColumn<Roomid, Integer> bookid;

    @FXML
    private TableColumn<Reservation, Number> roomnum;

    @FXML
    private TableColumn<Reservation, String> rtype;

    @FXML
    private TableColumn<Reservation, Number> bednum;

    @FXML
    private TableColumn<Reservation, Number> cost;

    @FXML
    private TableColumn<Reservation, LocalDate> resdate;

    @FXML
    private Button bookroom;

    @FXML
    private TextField searchbookid;

    @FXML
    private Button search;

    @FXML
    private Button resbtn;


    @FXML
    private Text idnum;

    @FXML
    void bookroom(ActionEvent event) {
        Parent rootparent = null;
        try {
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/reservation.fxml"));
            Scene rootscene=new Scene(rootparent);
            Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
            appstage.setResizable(false);
            appstage.setScene(rootscene);
            appstage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void viewroom(ActionEvent event) {

            Parent rootparent = null;
            try {
                rootparent = FXMLLoader.load(getClass().getResource("../FXML/custroom.fxml"));
                Scene rootscene=new Scene(rootparent);
                Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
                appstage.setResizable(false);
                appstage.setScene(rootscene);
                appstage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
    }

    @FXML
    void search(ActionEvent event) {


    }
    @FXML
    void exit(MouseEvent event) {
        Parent rootparent = null;
        try {
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/login.fxml"));
            Scene rootscene=new Scene(rootparent);
            Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
            appstage.setScene(rootscene);
            appstage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    try{
        bookid.setCellValueFactory(new PropertyValueFactory<Roomid, Integer>("roomid"));
        roomnum.setCellValueFactory(cellData ->
        {
            try {
                return new SimpleIntegerProperty(cellData.getValue().getRoom().getRoomnum());
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        });
            rtype.setCellValueFactory(cellData ->
                    new SimpleStringProperty(cellData.getValue().getRoom().getRoomtype()));
            bednum.setCellValueFactory(cellData ->
                    new SimpleIntegerProperty(cellData.getValue().getRoom().getNumbeds()));
            cost.setCellValueFactory(cellData ->
                    new SimpleFloatProperty(cellData.getValue().getRoom().getRoomcost()));
        resdate.setCellValueFactory(new PropertyValueFactory<Reservation, LocalDate>("resdate"));
            booktable.getItems().setAll(parseUserList());
        bookidtable.getItems().setAll(roomid());
        } catch (IOException e) {
            e.printStackTrace();
        }
        }

    private List<Reservation> parseUserList() throws IOException {
        RandomAccessFile resfile = null;
        PrintWriter writer = new PrintWriter("resid.txt", "UTF-8");

        Reservation r;
        Room room;
        Dimension d;

        List<Reservation> allres = new ArrayList<Reservation>();
        try {
            resfile = new RandomAccessFile("reservation.dat", "rw");
            for (int idx = 1; idx <= 1000; idx++) {
                resfile.seek((idx - 1) * offset);



                int id = resfile.readInt();
                String date = resfile.readUTF();
                int roomnum = resfile.readInt();
                int numbeds= resfile.readInt();
                String rtype=resfile.readUTF();
                float rcost = resfile.readFloat();
                int width = resfile.readInt();
                int lngth = resfile.readInt();
                writer.println(id);
                d = new Dimension(width, lngth);
                room = new Room(idx, numbeds, rtype, rcost, d);
                r =new Reservation(id,LocalDate.now(),room);
                allres.add(r);
                if (numbeds == 0) {
                    allres.remove(r);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("not in file");
            a.notfound();
        } catch (IOException e) {
            System.out.println("not in file");
        } finally {
            try {
                if (resfile != null) {
                    resfile.close();
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return allres;
    }
    private List<Roomid> roomid()
    {
        BufferedReader reader=null;
        List<Roomid> roomlist=new ArrayList<Roomid>();

        try {
            reader = new BufferedReader(new FileReader(
                        "resid.txt"));

            String line = reader.readLine();
            Roomid idc;
            while (line != null) {
                System.out.println("roomid"+line);
                int rid=Integer.parseInt(line);
                line = reader.readLine();
                if(rid!=0)
                {
                    idc=new Roomid(rid);
                    roomlist.add(idc);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e)
            {

            }
        }
        return roomlist;
    }
    public void setText(int id)
    {
        String result = Integer.toString(id);
        this.idnum.setText(result);
    }

}
