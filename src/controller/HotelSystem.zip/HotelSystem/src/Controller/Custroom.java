package Controller;

import IDCLASS.Roomid;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import Class.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;


public class Custroom implements Initializable {
    private int offset = (50 + (25 * 2) + (25 * 2) + (3 * 4) + (3 + 4) + (25 * 2) + (25 * 2) + (25 * 2) + (1 * 4));
    Alerts a=new Alerts();
    @FXML
    private TableView<Room> tableview;

    @FXML
    private TableView<Roomid> roomidtable;

    @FXML
    private TableColumn<Roomid, Integer> roomid;

    @FXML
    private TableColumn<Room, String> roomtype;

    @FXML
    private TableColumn<Room, Integer> bednum;

    @FXML
    private TableColumn<Room, Float> rcost;

    @FXML
    private TableColumn<Room, Number> width;

    @FXML
    private TableColumn<Room, Number> length;

    @FXML
    private TextField sroomid;


    @FXML
    void search(ActionEvent event) {
        try {
            int rid = Integer.parseInt(sroomid.getText());

            roomid.setCellValueFactory(new PropertyValueFactory<Roomid, Integer>("roomid"));

            roomtype.setCellValueFactory(new PropertyValueFactory<Room, String>("roomtype"));
            bednum.setCellValueFactory(new PropertyValueFactory<Room, Integer>("numbeds"));
            rcost.setCellValueFactory(new PropertyValueFactory<Room, Float>("roomcost"));
            width.setCellValueFactory(cellData ->
                    new SimpleIntegerProperty(cellData.getValue().getDimension().getWidth()));
            length.setCellValueFactory(cellData ->
                    new SimpleIntegerProperty(cellData.getValue().getDimension().getLength()));
            tableview.getItems().setAll(searchroom(rid));
            roomidtable.getItems().setAll(roomid());


        } catch (NumberFormatException e)
        {
            a.invalidinput();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void back(MouseEvent event) {
        Parent rootparent = null;
        try {
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/CustomerMenu.fxml"));
            Scene rootscene=new Scene(rootparent);
            Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
            appstage.setScene(rootscene);
            appstage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            roomid.setCellValueFactory(new PropertyValueFactory<Roomid, Integer>("roomid"));

            roomtype.setCellValueFactory(new PropertyValueFactory<Room, String>("roomtype"));
            bednum.setCellValueFactory(new PropertyValueFactory<Room, Integer>("numbeds"));
            rcost.setCellValueFactory(new PropertyValueFactory<Room, Float>("roomcost"));
            width.setCellValueFactory(cellData ->
                    new SimpleIntegerProperty(cellData.getValue().getDimension().getWidth()));
            length.setCellValueFactory(cellData ->
                    new SimpleIntegerProperty(cellData.getValue().getDimension().getLength()));


            tableview.getItems().setAll(parseUserList());

            roomidtable.getItems().setAll(roomid());



        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private List<Room> parseUserList() throws IOException {
        RandomAccessFile roomfile = null;
        Scanner scanner = new Scanner(new File("idx.txt"));
        PrintWriter writer = new PrintWriter("vroomid.txt", "UTF-8");


        List<Room> allroom = new ArrayList<Room>();
        try {
            roomfile = new RandomAccessFile("room.dat", "rw");
            for (int idx = 1; idx <= 1000; idx++) {
                roomfile.seek((idx - 1) * offset);

                Dimension d = new Dimension();
                Room r = new Room();

                int id = roomfile.readInt();
                int bednum = roomfile.readInt();
                String roomtype = roomfile.readUTF();
                float rcost = roomfile.readFloat();
                int width = roomfile.readInt();
                int lngth = roomfile.readInt();
                String swidth = Integer.toString(width);
                String slength = Integer.toString(lngth);
                System.out.println(id+" type"+roomtype);
                d = new Dimension(swidth, slength);
                writer.println(id);
                r = new Room(idx, bednum, roomtype, rcost, d);
                allroom.add(r);
                if (bednum == 0) {
                    allroom.remove(r);
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("not in file");
            a.notfound();
        } catch (IOException e) {
            System.out.println("not in file");
        } finally {
            try {
                if (roomfile != null) {
                    roomfile.close();
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return allroom;

    }


    private List<Room> searchroom(int num) throws IOException {
        RandomAccessFile roomfile = null;
        Scanner scanner = new Scanner(new File("idx.txt"));
        PrintWriter writer = new PrintWriter("vroomid.txt", "UTF-8");


        List<Room> allroom = new ArrayList<Room>();
        try {
            roomfile = new RandomAccessFile("room.dat", "rw");
            roomfile.seek((num - 1) * offset);


            Dimension d = new Dimension();
                Room r = new Room();

                int id = roomfile.readInt();
                int bednum = roomfile.readInt();
                String roomtype = roomfile.readUTF();
                float rcost = roomfile.readFloat();
                int width = roomfile.readInt();
                int lngth = roomfile.readInt();
                String swidth = Integer.toString(width);
                String slength = Integer.toString(lngth);
                System.out.println(id+" type"+roomtype);
                d = new Dimension(swidth, slength);
                writer.println(id);
                r = new Room(num, bednum, roomtype, rcost, d);
                allroom.add(r);
                if (bednum == 0) {
                    allroom.remove(r);
                }

            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("not in file");
            a.notfound();
        } catch (IOException e) {
            System.out.println("not in file");
        } finally {
            try {
                if (roomfile != null) {
                    roomfile.close();
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return allroom;
    }
    private List<Roomid> roomid()
    {
        BufferedReader reader=null;
        List<Roomid> roomlist=new ArrayList<Roomid>();

        try {
            reader = new BufferedReader(new FileReader(
                    "vroomid.txt"));

            String line = reader.readLine();
            Roomid idc;
            while (line != null) {
                System.out.println("roomid"+line);
                int rid=Integer.parseInt(line);
                line = reader.readLine();
                if(rid!=0)
                {
                    idc=new Roomid(rid);
                    roomlist.add(idc);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e)
            {

            }
        }
        return roomlist;
    }
}
