package Controller;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Logger;

import Class.*;

public class Login implements Initializable {
    private int offset = (50 + (25 * 2) + (25 * 2) + (3 * 4) + (3 + 4) + (25 * 2) + (25 * 2) + (25 * 2) + (1 * 4));
    Alerts a = new Alerts();
    @FXML
    private TextField username;

    @FXML
    private ChoiceBox<String> usertype;

    @FXML
    private PasswordField password;

    ObservableList<String> userlist = FXCollections.
            observableArrayList("Admin", "Staff", "Customer");

    @FXML
    void login(ActionEvent event) {
        Parent rootparent = null;

        try {
            String utype = usertype.getValue();
            String pword = password.getText();
            int uname = Integer.parseInt(username.getText());

            if (utype == "Admin") {
                if (uname == 1200 || pword.equals("admin")) {

                    System.out.println(uname + " pwp " + pword);
                    rootparent = FXMLLoader.load(getClass().getResource("../FXML/AdminMenu.fxml"));
                    Scene rootscene = new Scene(rootparent);
                    Stage appstage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    appstage.setResizable(false);
                    appstage.setScene(rootscene);
                    appstage.show();
                } else {
                    a.invalidinput();
                }
            }

            if (utype == "Customer") {
                int val=searchcustomer(uname, pword);
                System.out.println("jj"+val);
                if(val==1) {
                    System.out.println(uname + pword);
                    FXMLLoader loader=new FXMLLoader();
                    loader.setLocation(getClass().getResource("../FXML/CustomerMenu.fxml"));
                    try {
                        loader.load();
                    }catch (IOException EX)
                    {
                        EX.printStackTrace();
                    }
                    CustomerMenu cmenu=loader.getController();
                    cmenu.setText(uname);

                    Parent p=loader.getRoot();
                    Stage stage=new Stage();
                    stage.setScene(new Scene(p));
                    stage.show();
                }else
                {
                    a.invalidinput();
                }
            }

            if (utype == "Staff") {
                int val=searchstaff(uname, pword);
                System.out.println("jj"+val);
                if(val==1) {
                    System.out.println(uname + pword);
                    FXMLLoader loader=new FXMLLoader();
                    loader.setLocation(getClass().getResource("../FXML/StaffMenu.fxml"));
                    try {
                        loader.load();
                    }catch (IOException EX)
                    {
                        EX.printStackTrace();
                    }
                    StaffMenu smenu=loader.getController();
                    smenu.setText(uname);

                    Parent p=loader.getRoot();
                    Stage stage=new Stage();
                    stage.setScene(new Scene(p));
                    stage.show();
                }else
                {
                    a.invalidinput();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            a.invalidinput();
        }
    }
        @Override
        public void initialize (URL location, ResourceBundle resources){
            usertype.setValue("Customer");
            usertype.setItems(userlist);
        }

    private int searchstaff(int num,String p) throws IOException {
        RandomAccessFile raf = null;
        int val=0;
        Staff s=new Staff();

        try {
            raf = new RandomAccessFile("staff.dat", "rw");
            for (int idx = 1; idx <= 1000; idx++) {
                raf.seek((idx - 1) * offset);
                    int fileid = raf.readInt();
                    String pass = raf.readUTF();
                    String dob = raf.readUTF();
                    String edate = raf.readUTF();
                    String fname = raf.readUTF();
                    String lname = raf.readUTF();
                if(fileid==num ||pass.equals(p))
                {
                    val=1;
                    System.out.println("founddd");
                    System.out.println("found it::"+fileid + "  ccc " + pass);

                }
            }

        } catch (FileNotFoundException e) {
            System.out.println("not in file");
            a.notfound();
        } catch (IOException e) {
            System.out.println("not in file");
            //a.outofrange();
        } finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return val;
    }


    private int searchcustomer(int num,String p) throws IOException {
        RandomAccessFile raf = null;
        int val=0;
        Customer c;
        try {
            raf = new RandomAccessFile("customer.dat", "rw");
            for (int idx = 1; idx <= 1000; idx++) {
                raf.seek((idx - 1) * offset);

                int fileid = raf.readInt();
                String pass = raf.readUTF();
                String dob = raf.readUTF();
                int pnum = raf.readInt();
                String email = raf.readUTF();
                String fname = raf.readUTF();
                String lname = raf.readUTF();

                if (fileid == num || pass.equals(p)) {
                    val = 1;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("not in file");
            a.notfound();
        } catch (IOException e) {
            System.out.println("not in file");
            a.outofrange();
        } finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return val;
    }
}

