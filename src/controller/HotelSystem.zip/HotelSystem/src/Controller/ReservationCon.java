package Controller;

import IDCLASS.Roomid;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;
import Class.Dimension;
import Class.Room;
import Class.Reservation;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


public class ReservationCon implements Initializable {
    Reservation res;
    Room room;
    Alerts a=new Alerts();
    String rrtype;


    @FXML
    private ChoiceBox<String> rid;

    @FXML
    private TextField bednum;

    @FXML
    private TextField width;

    @FXML
    private TextField length;

    @FXML
    private ChoiceBox<String> rtype;

    @FXML
    private TextField rcost;

    @FXML
    private TextField resid;

    ObservableList<String> roomtype= FXCollections.
            observableArrayList("Single","Couple","Family");

    ObservableList<String> roomid=getRoomnum();
    ObservableList<String> rnumbers= FXCollections.
            observableArrayList(roomid);




    @FXML
    void bookroom(ActionEvent event) {
        Scanner scanner = null;
        try{
        scanner = new Scanner(new File("res.txt"));
        int storedresnum = scanner.nextInt();
            scanner = new Scanner(new File("res.txt"));
            int storedroomnun = scanner.nextInt();
            LocalDate now = LocalDate.now();
        int bnum = Integer.parseInt(bednum.getText());
        int wth = Integer.parseInt(width.getText());
        int lth = Integer.parseInt(length.getText());
        rrtype = rtype.getValue();
        float roomcost=0;
            if(rrtype.equals("Single"))
            {
                roomcost=200;
            }if(rrtype.equals("Couple"))
            {
                roomcost=400;
            }
            if(rrtype.equals("Family"))
            {
                roomcost=850;
            }
            Dimension d=new Dimension(wth,lth);
            room = new Room(storedroomnun,bnum,rrtype,roomcost,d);
            res=new Reservation(storedresnum,now,room);
            res.bookroom(res);

            Parent rootparent = null;
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/CustomerMenu.fxml"));
            Scene rootscene=new Scene(rootparent);
            Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
            appstage.setResizable(false);
            appstage.setScene(rootscene);
            appstage.show();
        } catch (NumberFormatException ex)
        {
            a.invalidinput();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void roomt(MouseEvent event) {
        rrtype = rtype.getValue();
       if(rrtype.equals("Single"))
        {
            rcost.setText("200");
        }if(rrtype.equals("Couple"))
        {
            rcost.setText("400");
        }
        if(rrtype.equals("Family"))
        {
            rcost.setText("850");
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        rtype.setValue("Single");
        rtype.setItems(roomtype);
        rtype.setValue("1300");
        rid.setItems(rnumbers);
        rcost.setText("200");
        Scanner scanner = null;
        RandomAccessFile r = null;
        try {
            scanner = new Scanner(new File("res.txt"));
            int intnum = scanner.nextInt();
            String result = Integer.toString(intnum);
            resid.setText(result);
            scanner = new Scanner(new File("room.txt"));
            int rnum = scanner.nextInt();
            String rresult = Integer.toString(rnum);
           // rid.setText(rresult);

            r = new RandomAccessFile(new File("reservation.dat"), "rw");
            for (int idx = 1; idx <= 1000; idx++) {
                r.seek((idx -1)*(4+(25*2)+4+4+4));
                r.writeInt(0);
                r.writeUTF("");
                r.writeUTF("");
                r.writeUTF("");
                r.writeUTF("");
                r.writeUTF("");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (r != null) {
                    r.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public ObservableList<String> getRoomnum() {
        BufferedReader reader=null;
        ObservableList<String> roomid = FXCollections.observableArrayList();
        try {
            reader = new BufferedReader(new FileReader(
                    "vroomid.txt"));

        String line = reader.readLine();
        while (line != null) {
            System.out.println("roomid" + line);
            line = reader.readLine();
            roomid.add(line);
        }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException E)
        {

        }
        return roomid;
    }
}
