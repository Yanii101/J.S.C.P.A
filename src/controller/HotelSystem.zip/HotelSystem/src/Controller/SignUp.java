package Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import Class.User;
import Class.Staff;
import Class.Customer;
import javafx.stage.Stage;


import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.Scanner;

public class SignUp implements Initializable {
    Staff staff;
    Customer customer;
    Alerts a=new Alerts();
    @FXML
    private TextField fname;

    @FXML
    private TextField password;

    @FXML
    private TextField userid;

    @FXML
    private TextField lname;

    @FXML
    private ChoiceBox<String> usertype;

    @FXML
    private DatePicker dob;

    @FXML
    private DatePicker empdate;

    ObservableList<String> utype= FXCollections.
            observableArrayList("Staff","Customer");

    @FXML
    void signup(ActionEvent event) {
        try {
            Scanner scanner = new Scanner(new File("idx.txt"));
            int intnum = scanner.nextInt();
            String firstname = fname.getText();
            String lastname = lname.getText();
            String utype = usertype.getValue();
            LocalDate dofb = dob.getValue();
            String pword = password.getText();
            LocalDate employdate = empdate.getValue();
            if (utype == "Staff") {
                staff = new Staff(intnum, pword, dofb, employdate, firstname, lastname);
                staff.addStaff(staff);
            } else if (utype == "Customer") {
                //user=new Staff(uid,pword,dofb,employdate,firstname,lastname);
            }
            a.success();
            scanner = new Scanner(new File("idx.txt"));
            int num = scanner.nextInt();
            Parent rootparent = null;

            rootparent = FXMLLoader.load(getClass().getResource("../FXML/AdminMenu.fxml"));
            Scene rootscene=new Scene(rootparent);
            Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
            appstage.setResizable(false);
            appstage.setScene(rootscene);
            appstage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        usertype.setValue("User Type");
        usertype.setItems(utype);

        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("idx.txt"));
            int intnum = scanner.nextInt();

            String result = Integer.toString(intnum);
            userid.setText(result);
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        RandomAccessFile f = null;
        try {
            f = new RandomAccessFile(new File("user.dat"), "rw");
            for (int idx = 1; idx <= 1000; idx++) {
                f.seek((idx -1)*(4+(25*2)+4+4+4));
                f.writeInt(0);
                f.writeUTF("");
                f.writeUTF("");
                f.writeUTF("");
                f.writeUTF("");
                f.writeUTF("");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (f != null) {
                    f.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
