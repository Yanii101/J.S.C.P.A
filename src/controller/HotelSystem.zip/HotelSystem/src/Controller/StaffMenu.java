package Controller;

import IDCLASS.Roomid;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import Class.*;

import java.io.*;
import java.net.URL;
import java.util.*;


public class StaffMenu implements Initializable {
    private int offset = (50 + (25 * 2) + (25 * 2) + (3 * 4) + (3 + 4) + (25 * 2) + (25 * 2) + (25 * 2) + (1 * 4));
    AddRoom ar=new AddRoom();
    Alerts a = new Alerts();
    @FXML
    private TableView<Room> tableview;

    @FXML
    private TableView<Roomid> roomidtable;

    @FXML
    private TableColumn<Roomid, Integer> roomnum;


    @FXML
    private TableColumn<Room, String> roomtype;

    @FXML
    private TableColumn<Room, Integer> bednum;

    @FXML
    private TableColumn<Room, Float> rcost;

    @FXML
    private TableColumn<Room, Number> width;

    @FXML
    private TableColumn<Room, Number> length;

    @FXML
    private Text idum;

    @FXML
    private TextField sroomid;

    @FXML
    void addroom(ActionEvent event) {
        Parent rootparent = null;
        try {
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/AddRoom.fxml"));
            Scene rootscene = new Scene(rootparent);
            Stage appstage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            appstage.setResizable(false);
            appstage.setScene(rootscene);
            appstage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void bookroom(ActionEvent event) {
        Parent rootparent = null;
        try {
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/reservation.fxml"));
            Scene rootscene = new Scene(rootparent);
            Stage appstage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            appstage.setResizable(false);
            appstage.setScene(rootscene);
            appstage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    void delete(ActionEvent event) {
        int rid = Integer.parseInt(sroomid.getText());

        Room r=new Room();
        RandomAccessFile raf=null;
        try{
            raf = new RandomAccessFile("room.dat", "rw");
            raf.seek((rid - 1) * offset);
            raf.writeInt(r.getRoomnum());
            raf.writeUTF(r.getRoomtype());
            raf.writeInt(r.getNumbeds());
            raf.writeFloat(r.getRoomcost());
            //raf.writeInt(r.getDimension().getLength());
          //  raf.writeInt(r.getDimension().getLength());
            a.success();
            Parent rootparent = null;
                rootparent = FXMLLoader.load(getClass().getResource("../FXML/StaffMenu.fxml"));
                Scene rootscene=new Scene(rootparent);
                Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
                appstage.setScene(rootscene);
                appstage.show();



        } catch (IOException e) {
            System.out.println("not in file");
            a.invalidinput();
        }finally {
            try {
                if (raf != null) {
                    raf.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    void back(MouseEvent event) {
        Parent rootparent = null;
        try {
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/StaffMenu.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Scene rootscene=new Scene(rootparent);
        Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
        appstage.setScene(rootscene);
        appstage.show();
    }
    @FXML
    void search(ActionEvent event) {
        try {
            int rid = Integer.parseInt(sroomid.getText());

            roomnum.setCellValueFactory(new PropertyValueFactory<Roomid, Integer>("roomid"));

            roomtype.setCellValueFactory(new PropertyValueFactory<Room, String>("roomtype"));
            bednum.setCellValueFactory(new PropertyValueFactory<Room, Integer>("numbeds"));
            rcost.setCellValueFactory(new PropertyValueFactory<Room, Float>("roomcost"));
            width.setCellValueFactory(cellData ->
                    new SimpleIntegerProperty(cellData.getValue().getDimension().getWidth()));
            length.setCellValueFactory(cellData ->
                    new SimpleIntegerProperty(cellData.getValue().getDimension().getLength()));
            tableview.getItems().setAll(searchroom(rid));
            roomidtable.getItems().setAll(roomid());


        } catch (NumberFormatException e)
        {
            a.invalidinput();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            roomnum.setCellValueFactory(new PropertyValueFactory<Roomid, Integer>("roomid"));

            roomtype.setCellValueFactory(new PropertyValueFactory<Room, String>("roomtype"));
            bednum.setCellValueFactory(new PropertyValueFactory<Room, Integer>("numbeds"));
            rcost.setCellValueFactory(new PropertyValueFactory<Room, Float>("roomcost"));
            width.setCellValueFactory(cellData ->
                    new SimpleIntegerProperty(cellData.getValue().getDimension().getWidth()));
            length.setCellValueFactory(cellData ->
                    new SimpleIntegerProperty(cellData.getValue().getDimension().getLength()));

            tableview.getItems().setAll(parseUserList());

            roomidtable.getItems().setAll(roomid());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private List<Roomid> roomid()
    {
        BufferedReader reader=null;
        List<Roomid> roomlist=new ArrayList<Roomid>();

        try {
            reader = new BufferedReader(new FileReader(
                    "vroomid.txt"));

            String line = reader.readLine();
            Roomid idc;
            while (line != null) {
                System.out.println("roomid"+line);
                int rid=Integer.parseInt(line);
                line = reader.readLine();
                if(rid!=0)
                {
                    idc=new Roomid(rid);
                    roomlist.add(idc);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e)
            {

            }
        }
        return roomlist;
    }

    private List<Room> parseUserList() throws IOException {
        RandomAccessFile roomfile = null;
        Scanner scanner = new Scanner(new File("idx.txt"));
        PrintWriter writer = new PrintWriter("vroomid.txt", "UTF-8");


        List<Room> allroom = new ArrayList<Room>();
        try {
            roomfile = new RandomAccessFile("room.dat", "rw");
            for (int idx = 1; idx <= 1000; idx++) {
                roomfile.seek((idx - 1) * offset);

                Dimension d = new Dimension();
                Room r = new Room();

                int id = roomfile.readInt();
                int bednum = roomfile.readInt();
                String roomtype = roomfile.readUTF();
                float rcost = roomfile.readFloat();
                int width = roomfile.readInt();
                int lngth = roomfile.readInt();
                String swidth = Integer.toString(width);
                String slength = Integer.toString(lngth);

                 writer.println(id);
                d = new Dimension(swidth, slength);
                r = new Room(idx, bednum, roomtype, rcost, d);
                allroom.add(r);
                if (bednum == 0) {
                    allroom.remove(r);
                }

            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("not in file");
            a.notfound();
        } catch (IOException e) {
            System.out.println("not in file");
        } finally {
            try {
                if (roomfile != null) {
                    roomfile.close();
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return allroom;

    }

    @FXML
    void exit(MouseEvent event) {
        Parent rootparent = null;
        try {
            rootparent = FXMLLoader.load(getClass().getResource("../FXML/login.fxml"));
            Scene rootscene=new Scene(rootparent);
            Stage appstage=(Stage)((Node)event.getSource()).getScene().getWindow();
            appstage.setScene(rootscene);
            appstage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private List<Room> searchroom(int num) throws IOException {
        RandomAccessFile roomfile = null;
        PrintWriter writer = new PrintWriter("vroomid.txt", "UTF-8");
        List<Room> allroom = new ArrayList<Room>();
        try {
            roomfile = new RandomAccessFile("room.dat", "rw");
            roomfile.seek((num - 1) * offset);
            Dimension d = new Dimension();
            Room r = new Room();


            int id = roomfile.readInt();
            int bednum = roomfile.readInt();
            String roomtype = roomfile.readUTF();
            float rcost = roomfile.readFloat();
            int width = roomfile.readInt();
            int lngth = roomfile.readInt();
            System.out.println("rtpe"+roomtype);
            writer.println(id);
            d = new Dimension(width, lngth);
            r = new Room(num, bednum, roomtype, rcost, d);
            allroom.add(r);
            if (bednum == 0) {
                allroom.remove(r);
            }
        } catch (FileNotFoundException e) {
            System.out.println("not in file");
            a.notfound();
        } catch (IOException e) {
            System.out.println("not in file");
            a.outofrange();
        } finally {
            try {
                if (roomfile != null) {
                    roomfile.close();
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return allroom;

    }

    public void setText(int id)
    {
        String result = Integer.toString(id);
        this.idum.setText(result);
    }


}

