package IDCLASS;

public class Resid {
    int resid;
    public Resid() {
        this(0);
    }
    public Resid(int resid) {
        this.resid = resid;
    }

    public int getResid() {
        return resid;
    }

    public void setResid(int resid) {
        this.resid = resid;
    }
}
