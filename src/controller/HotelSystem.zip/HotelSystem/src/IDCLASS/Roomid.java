package IDCLASS;

public class Roomid {
    private int roomid,userid,resid;


    public Roomid() {
        this( 0);
    }

    public Roomid(int roomid) {
        this.roomid = roomid;
    }

    public void setRoomid(int roomid) {
        this.roomid = roomid;
    }
    public int getRoomid() {
        return roomid;
    }
}
